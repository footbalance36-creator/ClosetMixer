---
name: Closet Mixer
colors:
  surface: '#faf9f7'
  surface-dim: '#dadad8'
  surface-bright: '#faf9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeec'
  surface-container-high: '#e9e8e6'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1b'
  on-surface-variant: '#4d4635'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#7f7663'
  outline-variant: '#d0c5af'
  surface-tint: '#735c00'
  primary: '#735c00'
  on-primary: '#ffffff'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#e9c349'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e4e2e2'
  on-secondary-container: '#646464'
  tertiary: '#415ba4'
  on-tertiary: '#ffffff'
  tertiary-container: '#97b0ff'
  on-tertiary-container: '#254188'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e4e2e2'
  secondary-fixed-dim: '#c8c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#27438a'
  background: '#faf9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e3e2e0'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 20px
  margin-desktop: 40px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  section-gap: 48px
---

## Brand & Style
The design system for this application is rooted in **Luxury Minimalism**. It targets fashion-conscious individuals who value organization as much as expression. The UI must feel like a high-end digital boutique—calm, curated, and expensive. 

The aesthetic prioritizes generous whitespace to let clothing photography take center stage. By utilizing a mix of editorial typography and a "Gallery" layout approach, the interface recedes to ensure the user's wardrobe becomes the primary visual content. The emotional goal is to evoke a sense of order, sophistication, and effortless style.

## Colors
The palette is built on a "Warm Neutral" foundation to avoid the sterile feeling of pure black and white. 
- **Primary (Champagne Gold):** Used sparingly for high-intent actions, active states, and premium features.
- **Neutrals:** A range of off-whites (`#F9F8F6`) and soft grays provide depth without introducing hue conflict with user-uploaded clothing photos.
- **Deep Charcoal:** Used for primary text and iconography to maintain high legibility while appearing softer than pure black.
- **Soft Clay:** An auxiliary accent used for categorizing or secondary highlights, maintaining the earthy, sophisticated vibe.

## Typography
The typographic hierarchy relies on the contrast between the authoritative, high-contrast **Playfair Display** (Serif) and the functional, neutral **Inter** (Sans-serif). 

- **Headlines:** Use Serif for all page titles and outfit names to convey an editorial, magazine-like feel.
- **Body & Controls:** Use Sans-serif for wardrobe data, settings, and navigation to ensure clarity across multiple languages and script types.
- **Labels:** Use uppercase Inter with slight letter spacing for category chips and small metadata to create a "tabbed" or "archival" look.

## Layout & Spacing
The layout follows a **Fluid Grid** model with emphasized vertical rhythm. 
- **Margins:** A generous 20px margin on mobile devices ensures content doesn't feel cramped.
- **Grid:** Wardrobe items are displayed in a 2-column or 3-column grid depending on category, using a 16px gutter to maintain "breathing room."
- **RTL Support:** All layouts are designed with logical properties (padding-inline, margin-inline) to seamlessly flip for Arabic or Hebrew character sets.
- **Photography Focus:** Vertical aspect ratios (3:4) are preferred for wardrobe items to align with fashion industry standards.

## Elevation & Depth
Depth is achieved through **Tonal Layers** and extremely **Ambient Shadows**. 
- **Surface Tiering:** The base background is white, while interactive cards or sections use the off-white surface color (`#F2F0ED`) to create subtle separation without harsh lines.
- **Shadows:** Use a "Large & Soft" shadow profile for floating elements like the "Add Item" button or Outfit Banners (Blur: 30px, Y-offset: 10px, Opacity: 4% Black). 
- **Borders:** Hairline borders (0.5px) in a light gray-beige are used only when necessary for structural clarity in data-heavy views like the Calendar.

## Shapes
The design system utilizes **Rounded** shapes to soften the minimalist aesthetic and make the app feel approachable. 
- **Standard Cards:** 16px (1rem) corner radius.
- **Buttons & Chips:** 32px (Pill-shaped) for a modern, tactile feel.
- **Image Containers:** Must match the 16px radius of their parent containers to maintain visual harmony.

## Components
- **Wardrobe Grid & Chips:** Items are displayed as 3:4 cards with no borders. Category chips use a "Ghost" style (light neutral background) and move to a "Solid Clay" background when active.
- **Weather-Aware Outfit Banners:** Large-scale horizontal cards at the top of the dashboard. They utilize a background blur (Glassmorphism) over a lifestyle image to display weather icons and "Suggested for Today" text.
- **Calendar Planning:** A clean, dot-indicator based monthly view. Selected dates use the Champagne Gold accent as a soft circular glow behind the date.
- **Input Fields:** Bottom-bordered only (minimalist style) or fully rounded with a soft neutral fill. Focus states are indicated by a Champagne Gold underline.
- **Statistics:** Use "Thin Line" charts in Deep Charcoal with Champagne Gold data points. Avoid heavy fills; prioritize clean, architectural lines.
- **Language/Culture Selector:** A specialized list component where each option (e.g., "Modest") includes a subtle descriptive icon and a toggle. The layout remains symmetrical to accommodate varied text lengths.